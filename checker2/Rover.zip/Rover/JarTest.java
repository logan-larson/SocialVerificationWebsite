import aCheck.*;

public class JarTest{


    public static void main(String args[]){
        System.out.println("starting test starting test 2");
        ModelFileChecker test = new ModelFileChecker("123");


    }




}