/**
 * Utility functions for operations on vectors of doubles or integers (stored in C++ through JNI).
 */
package dv;
